﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание1
{
    class Program
    {
        static void Main (string [ ] args)
        {
            Cat murzic = new Cat("Мурзик", 4.0);
            Cat barsik = new Cat("Барсик", 8.0);
            murzic.Meow( );
            barsik.Meow( );
            barsik.Name = "Барсик";
            barsik.Meow( );
            barsik.Name = "1234";
            barsik.Meow( );

            Console.ReadKey( );
        }
    }
}
